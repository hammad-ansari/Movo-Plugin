<?php

/**
 * Fired during plugin activation
 *
 * @link       https://dixeam.com
 * @since      1.0.0
 *
 * @package    Movo
 * @subpackage Movo/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Movo
 * @subpackage Movo/includes
 * @author     Dixeam <info@dixeam.com>
 */
class Movo_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		if(empty(get_option('movo_images_ids'))){
			$all_images_path = [
				plugin_dir_path( __FILE__ ).'images/Black-Footer.png',
				plugin_dir_path( __FILE__ ).'images/Gray-Footer.png',
				plugin_dir_path( __FILE__ ).'images/TopStripBlack.png',
				plugin_dir_path( __FILE__ ).'images/TopStripBlue.png',
				plugin_dir_path( __FILE__ ).'images/WhiteFooter.png',
				plugin_dir_path( __FILE__ ).'images/cart-element.jpg',
			];
			$all_images_ids = [];
			foreach($all_images_path as $image_url){

				$upload_dir = wp_upload_dir();

				$image_data = file_get_contents( $image_url );

				$filename = basename( $image_url );

				if ( wp_mkdir_p( $upload_dir['path'] ) ) {
					$file = $upload_dir['path'] . '/' . $filename;
				}
				else {
					$file = $upload_dir['basedir'] . '/' . $filename;
				}

				file_put_contents( $file, $image_data );

				$wp_filetype = wp_check_filetype( $filename, null );

				$attachment = array(
					'post_mime_type' => $wp_filetype['type'],
					'post_title' => sanitize_file_name( $filename ),
					'post_content' => '',
					'post_status' => 'inherit'
				);

				$attach_id = wp_insert_attachment( $attachment, $file );
				$all_images_ids[] = [
					$filename => $attach_id
				];

				require_once( ABSPATH . 'wp-admin/includes/image.php' );
				$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
				wp_update_attachment_metadata( $attach_id, $attach_data );

			}
			add_option('movo_images_ids', json_encode($all_images_ids));
		}
		if(is_plugin_active('woocommerce/woocommerce.php')){

			add_option('movo_setup_check_notice', "Click here to setup Movo plugin.");
			add_option('movo_language', 'en');
			add_option('enable_on_cart', '0');

			return;
		}else{
			add_option('movo_woocommerce_check_notice', "Movo is integrated with woocommerce. It's important to setup woocommerce before setting up Move.");
			return;
		}
	}


}
