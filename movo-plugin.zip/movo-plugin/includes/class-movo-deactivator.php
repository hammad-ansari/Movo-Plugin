<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://dixeam.com
 * @since      1.0.0
 *
 * @package    Movo
 * @subpackage Movo/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Movo
 * @subpackage Movo/includes
 * @author     Dixeam <info@dixeam.com>
 */
class Movo_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
