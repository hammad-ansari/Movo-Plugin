(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 $( window ).load(function() {
	 	const params = new Proxy(new URLSearchParams(window.location.search), {
	 		get: (searchParams, prop) => searchParams.get(prop),
	 	});
	 	let value = params.page;

	 	if(value == 'movo-settings'){
	 		jQuery('#wpbody').css('top', '60px')
	 		jQuery('#wpcontent').css('padding-left', '0px')

	 	}
	 });

	 jQuery(document).on('change', '.movo_top_strip_mode', function(){
	 	var val = jQuery(this).val();
	 	// alert(val)
	 	if(val == 'light'){
	 		jQuery('.top_strip_demo').attr('src', $('.light_image_demo').val())
	 	}else if(val == 'dark'){
	 		jQuery('.top_strip_demo').attr('src', $('.dark_image_demo').val())
	 	}
	 })

	 jQuery(document).on('change', '.movo_footer_strip_mode', function(){
	 	var val = jQuery(this).val();
	 	if(val == 'light'){
	 	// alert($('.footer_light_image_demo').val())
	 		jQuery('.footer_strip_demo').attr('src', $('.footer_light_image_demo').val())
	 	}else if(val == 'dark'){
	 		jQuery('.footer_strip_demo').attr('src', $('.footer_dark_image_demo').val())
	 	}else if(val == 'grey'){
	 		jQuery('.footer_strip_demo').attr('src', $('.footer_grey_image_demo').val())
	 	}
	 })

	})( jQuery );

	function opentab(evt, tabName) {
		var i, tabcontent, tablinks;
		tabcontent = document.getElementsByClassName("movo-tabcontent");
		for (i = 0; i < tabcontent.length; i++) {
			tabcontent[i].style.display = "none";
		}
		tablinks = document.getElementsByClassName("movo-tablinks");
		for (i = 0; i < tablinks.length; i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
		document.getElementById(tabName).style.display = "block";
		evt.currentTarget.className += " active";
	}

