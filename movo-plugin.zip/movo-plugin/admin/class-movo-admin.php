<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://dixeam.com
 * @since      1.0.0
 *
 * @package    Movo
 * @subpackage Movo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Movo
 * @subpackage Movo/admin
 * @author     Dixeam <info@dixeam.com>
 */
class Movo_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Movo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Movo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/movo-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Movo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Movo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/movo-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function movo_add_admin_notices() {

		/**
		 * To check if woocommerce is already setup in website
		 */
		if(get_option('movo_woocommerce_check_notice')){
			
			if(!empty(get_option('movo_woocommerce_check_notice'))){
				echo '<div class="notice notice-error"><p>'.get_option('movo_woocommerce_check_notice').'</p></div>';
			}

		}

	}

	public function movo_admin_init() {

		/**
		 * To check if woocommerce is already setup
		 */
		include_once ABSPATH . 'wp-admin/includes/plugin.php';

		if(is_plugin_active('woocommerce/woocommerce.php')){
			update_option('movo_woocommerce_check_notice', '');
			if(empty(get_option('movo_images_ids'))){
				$all_images_path = [
					plugin_dir_url(__DIR__).'includes/images/Black-Footer.png',
					plugin_dir_url(__DIR__).'includes/images/Gray-Footer.png',
					plugin_dir_url(__DIR__).'includes/images/TopStripBlack.png',
					plugin_dir_url(__DIR__).'includes/images/TopStripBlue.png',
					plugin_dir_url(__DIR__).'includes/images/WhiteFooter.png',
					plugin_dir_url(__DIR__).'includes/images/cart-element.jpg',
				];
				$all_images_ids = [];
				foreach($all_images_path as $image_url){

					$upload_dir = wp_upload_dir();

					$image_data = file_get_contents( $image_url );

					$filename = basename( $image_url );

					if ( wp_mkdir_p( $upload_dir['path'] ) ) {
						$file = $upload_dir['path'] . '/' . $filename;
					}
					else {
						$file = $upload_dir['basedir'] . '/' . $filename;
					}

					file_put_contents( $file, $image_data );

					$wp_filetype = wp_check_filetype( $filename, null );

					$attachment = array(
						'post_mime_type' => $wp_filetype['type'],
						'post_title' => sanitize_file_name( $filename ),
						'post_content' => '',
						'post_status' => 'inherit'
					);

					$attach_id = wp_insert_attachment( $attachment, $file );
					$all_images_ids[] = [
						$filename => $attach_id
					];

					require_once( ABSPATH . 'wp-admin/includes/image.php' );
					$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
					wp_update_attachment_metadata( $attach_id, $attach_data );

				}
				add_option('movo_images_ids', json_encode($all_images_ids));

			}
			return;

		}else{
			update_option('movo_woocommerce_check_notice', "Movo is integrated with woocommerce. It's important to setup woocommerce before setting up Move.");
			return;
		}

	}

	public function movo_admin_menu_page() {

		/**
		 * To add menu page
		 */

		add_menu_page( 'Movo Settings', 
			'Movo Settings', 'manage_options', 
			'movo-settings', [self::class,'admin_menu_page_content'], 
			'dashicons-admin-settings', 6 );
	}
	public function woocom_general_product_data_custom_field() {
		if(is_plugin_active('woocommerce/woocommerce.php')){
			$movo_product_tags = json_decode(get_option('movo_product_tags'));
			$options = [];
			foreach($movo_product_tags as $title => $volume){
				$options[$volume] = __( $title, 'woocommerce' );
			}
			woocommerce_wp_select( array(
				'id'      => 'movo_product_level_field',
				'label'   => __( 'Movo Product Tag', 'woocommerce' ),
				'options' =>  $options,
			) );
		}

	}
	public function woocom_save_general_proddata_custom_field() {
		if(is_plugin_active('woocommerce/woocommerce.php')){
			$number_field = $_POST['movo_product_level_field'];
			if( ! empty( $number_field ) ) {
				update_post_meta( get_the_ID(), 'movo_product_level_field', esc_attr( $number_field ) );
			}
		}
	}
	public static function admin_menu_page_content() {
		?>
		<div class="">
			<?php include( 'partials/plugin-header.php' ); ?>
			<?php include( 'partials/content/top-strip.php' ); ?>
			<?php include( 'partials/content/footer-strip.php' ); ?>
			<?php include( 'partials/content/cart-element.php' ); ?>
			<?php include( 'partials/content/bags.php' ); ?>
		</div>

		<?php
	}
	
	public function product_custom_field_quick_edit() {
	   global $post;
		
		$movo_product_tags = json_decode(get_option('movo_product_tags'));
		$selected_tag = get_post_meta( $post->ID, 'movo_product_level_field', true );
		$options = [];
		foreach($movo_product_tags as $title => $volume){
			$options[$volume] = __( $title, 'woocommerce' );
		}
		woocommerce_wp_select( array(
			'id'      => 'movo_product_level_field',
			'label'   => __( 'Movo Product Tag', 'woocommerce' ),
			'selected' => true,
			'value'    => $selected_tag,
			'options' =>  $options,
		) );
		
	}
	
	public function show_custom_field_quick_edit_data( $column, $post_id ){
		if ( 'name' !== $column ) return;
		echo '<div>Custom field: <span id="cf_' . $post_id . '">' . esc_html( get_post_meta( $post_id, 'movo_product_level_field', true ) ) . '</span></div>';
	   wc_enqueue_js( "
		  $('#the-list').on('click', '.editinline', function() {
			 var post_id = $(this).closest('tr').attr('id');
			 post_id = post_id.replace('post-', '');
			 var custom_field = $('#cf_' + post_id).text();
			 $('input[name=\'movo_product_level_field\']', '.inline-edit-row').val(custom_field);
			});
	   " );
	}
	
	public function save_custom_field_quick_edit( $product ) {
		$post_id = $product->get_id();
		if ( isset( $_REQUEST['movo_product_level_field'] ) ) {
			$custom_field = $_REQUEST['movo_product_level_field'];
			update_post_meta( $post_id, 'movo_product_level_field', wc_clean( $custom_field ) );
		}
	}
	
}
