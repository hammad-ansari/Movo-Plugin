<div class="movo-top-header">
	<div class="movo-tab">
		<button class="movo-tablinks active" onclick="opentab(event, 'Top Strip')">Top Strip</button>
		<button class="movo-tablinks" onclick="opentab(event, 'Footer Strip')">Footer Mention</button>
		<button class="movo-tablinks" onclick="opentab(event, 'Cart Element')">Cart Element</button>
		<button class="movo-tablinks" onclick="opentab(event, 'Shopping Bags')">Bags & Others</button>
	</div>
</div>