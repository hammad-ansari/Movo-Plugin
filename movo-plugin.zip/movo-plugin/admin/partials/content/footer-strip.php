<div id="Footer Strip" class="movo-tabcontent">
	
	<div class="movo-content">
		<div class="movo-card">
			<?php
			$all_images = json_decode(get_option('movo_images_ids'));
			
			if(is_array($all_images)){
				$black = array_column($all_images, 'Black-Footer.png')[0];
				$light = array_column($all_images, 'WhiteFooter.png')[0];
				$grey = array_column($all_images, 'Gray-Footer.png')[0];
				$cart_element = array_column($all_images, 'cart-element.jpg')[0];
			}
			
						// print_r(wp_get_attachment_image_url($black, 'large'));
						// echo "</pre>";

			$top_strip = json_decode(@get_option('movo_footer_strip'));
			?>
			<input type="hidden" class="footer_dark_image_demo" value="<?= wp_get_attachment_image_url(@$black, 'large'); ?>">
			<input type="hidden" class="footer_light_image_demo" value="<?= wp_get_attachment_image_url(@$light, 'large'); ?>">
			<input type="hidden" class="footer_grey_image_demo" value="<?= wp_get_attachment_image_url(@$grey, 'large'); ?>">
			<?php
			$movo_footer_strip_settings = json_decode(get_option('movo_footer_strip'));

			if(empty($footer_strip)){
				?>
				<img src="<?= wp_get_attachment_image_url(@$black, 'large'); ?>" class="footer_strip_demo" alt="">
				<?php
			}else{
				if($movo_footer_strip_settings->movo_footer_strip_mode == 'dark'){
					?>
					<img src="<?= wp_get_attachment_image_url(@$black, 'large'); ?>" class="footer_strip_demo" alt="">

					<?php
				}elseif($movo_footer_strip_settings->movo_footer_strip_mode == 'light'){
					?>
					<img src="<?= wp_get_attachment_image_url(@$light, 'large'); ?>" class="footer_strip_demo" alt="">
					<?php
				}else{
					?>
					<img src="<?= wp_get_attachment_image_url(@$grey, 'large'); ?>" class="footer_strip_demo" alt="">
					<?php
				}
			}


			if(isset($_POST['submit_footer_strip'])){
							// echo "<pre>";
							// print_r($_POST);
				$data = json_encode([
					'enable_footer_strip' => $_POST['enable_footer_strip'],
					'movo_footer_strip_mode' => $_POST['movo_footer_strip_mode']
				]);
				if(empty(get_option('movo_footer_strip'))){
					add_option('movo_footer_strip', $data);
				}else{

					update_option('movo_footer_strip', $data);
				}

				echo "<script type='text/javascript'>window.location=document.location.href;</script>";	
			}
			?>
			
		</div>
		<form action="" method="post">
			<div class="movo-card" style="padding: 10px;margin-top: 10px">
				<div class="movo-card-header">
					<h4>Footer Mention</h4>
					<label class="switch">
						<input type="checkbox" <?php if(@$movo_footer_strip_settings->enable_footer_strip == '1'){ echo "checked"; } ?> class="movo-toggle" name="enable_footer_strip" value="1" />
						<span class="slider round"></span>
					</label>
				</div>
				<div class="movo-card-content">
					<h5>Appearance</h5>
					<ul class="movo-toggle-ul">
						<li>
							<input type="radio" class="movo_footer_strip_mode" <?php if(@$movo_footer_strip_settings->movo_footer_strip_mode == 'light'){ echo "checked"; } ?> value="light" id="s-option2" name="movo_footer_strip_mode">
							<label for="s-option2">Light Mode <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">For the light mode lovers.</span></label>

							<div class="check"><div class="inside"></div></div>
						</li>
						<li>
							<input type="radio" class="movo_footer_strip_mode" <?php if(@$movo_footer_strip_settings->movo_footer_strip_mode == 'grey'){ echo "checked"; } ?> value="grey" id="s-option3" name="movo_footer_strip_mode">
							<label for="s-option3">Grey Mode <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">For the one's who likes it grey.</span></label>

							<div class="check"><div class="inside"></div></div>
						</li>
						<li>
							<?php
										// echo "<pre>";
										// print_r($movo_footer_strip_settings);
							?>
							<input type="radio" value="dark" <?php if(@$movo_footer_strip_settings->movo_footer_strip_mode == 'dark'){ echo "checked"; } ?> class="movo_footer_strip_mode" id="f-option123" name="movo_footer_strip_mode">
							<label for="f-option123">Dark Mode <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">For the dark mode lovers.</span></label>

							<div class="check"></div>
						</li>

					</ul>
					<div style="text-align: right">
						<button type="submit" name="submit_footer_strip" class="movo-submit">Save Changes</button>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>