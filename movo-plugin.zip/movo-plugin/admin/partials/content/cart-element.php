<div id="Cart Element" class="movo-tabcontent">
				<?php
				if(isset($_POST['submit_cart_settings'])){
					update_option('movo_enable_on_cart', $_POST['movo_enable_on_cart']);
					update_option('movo_checked_on_cart', $_POST['movo_checked_on_cart']);
					echo "<script type='text/javascript'>window.location=document.location.href;</script>";	
				}
				?>
				<div class="movo-content">
					<div class="movo-card">
						<img src="<?= wp_get_attachment_image_url(@$cart_element, 'large'); ?>" class="footer_strip_demo" alt="">
					</div>
					<?php
					$movo_enable_on_cart = @get_option('movo_enable_on_cart');
					$movo_checked_on_cart = @get_option('movo_checked_on_cart');
					?>
					<form action="" method="post">
						<div class="movo-card" style="padding: 10px;margin-top: 10px">
							<div class="movo-card-header">
								<h4>Cart Element</h4>
								<label class="switch">
									<input type="checkbox" <?php if(@$movo_enable_on_cart == '1'){ echo "checked"; } ?> class="movo-toggle" name="movo_enable_on_cart" value="1" />
									<span class="slider round"></span>
								</label>
							</div>
							<div class="movo-card-content">
								<h5>Apperance</h5>
								<div>
									<label>
										<input type="checkbox" name="movo_checked_on_cart" <?php if(@$movo_checked_on_cart == '1'){ echo "checked"; } ?> value="1" > Checked By Default
									</label>
								</div>
								<p style="">
									Use to de-emphasize a piece of text that is less important to merchants than other nearby text. May also be used to indicate when normal content is absent, for example, “No supplier listed”. Don’t use only for aesthetic effect.
								</p>
								<div style="text-align: right">
									<button type="submit" name="submit_cart_settings" class="movo-submit">Save Changes</button>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>