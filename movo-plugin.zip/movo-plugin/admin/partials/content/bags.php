<div id="Shopping Bags" class="movo-tabcontent">
	<?php
	if(isset($_POST['submit_bags'])){
		update_option('movo_language', $_POST['movo_language']);					

		echo "<script type='text/javascript'>window.location=document.location.href;</script>";	
		
	}

	if(isset($_POST['movo_token_save'])){
		update_option('store_access_token', $_POST['store_access_token']);					

		echo "<script type='text/javascript'>window.location=document.location.href;</script>";	
	}
	if(isset($_POST['movo_token_sync'])){
		
		wp_insert_term( 'Movo Products', 'product_cat', array(
			'description' => 'Movo Products',
			'parent' => 0,
			'slug' => 'movo-cat'
		));


		$movo_product_tags = [
			"" => "",
			"T-shirt & Top" =>"1.632",
			"Pants" =>"10.8",
			"Shirt" =>"3.264",
			"Man Underwear" =>"1.512",
			"Woman Underwear" =>"1.4",
			"Man Swimsuit" =>"4.8",
			"Woman Swimsuit" =>"1.8",
			"Woman Dress" =>"5",
			"Skirt" =>"3.6",
			"Shorts" =>"2.8",
			"Jeans Male" =>"10.8",
			"Jeans Female" =>"8.19",
			"Tracksuit Pants" =>"9.9",
			"Tracksuit Hoodie" =>"4.862",
			"Tracksuit Full" =>"15.776",
			"Pullover and Cardigan" =>"5.25",
			"Sweatshirt" =>"4.862",
			"Soks and Tights" =>"1.56",
			"Short Soks" =>"0.288",
			"Bra" =>"2",
			"Slip" =>"1.4",
			"Shaping Underwear" =>"1.8",
			"Pajama (pants + t-shirt)" =>"4.455",
			"Garter Belt" =>"1.4",
			"Bathrobe" =>"28.56",
			"Shoes >43" =>"22.2075",
			"Boots" =>"40",
			"Bag 1 - Pochette" =>"7",
			"Bag 2" =>"14",
			"Bag 3" =>"28",
			"JACKET" =>"0",
			"Duvet Jacket Man" =>"57",
			"Coat Man" =>"24.624",
			"Winter Light Jacket Man" =>"25.92",
			"Windproof Jacket Man" =>"14.21",
			"Spring Jacket Man" =>"14.8",
			"ACCESSORIES" =>"0",
			"Sunglasses" =>"0.714",
			"Watch (G-Shock)" =>"1.29675",
			"Wallet (NAVA)" =>"0.912",
			"School Bag" =>"24.3",
			"Belt" =>"1.764",
			"Hat" =>"4",
			"Foulard" =>"7.90125",
			"Scarf" =>"9.2",
			"Mask Woven" =>"1.2",
			"Light Gloves" =>"2",
			"Heavy Gloves" =>"0",
			"Pouch" =>"1.5",
			"Small Umbrella" =>"2",
			"JEWELRY" =>"0",
			"Ring" =>"1.6",
			"Earrings" =>"1.6",
			"Necklece" =>"1.6",
			"Bracelet" =>"1.6",
			"MAKEUP" =>"0",
			"Box 1" =>"0.7",
			"Box 2" =>"1.4",
			"Box 3" =>"2.8",
			"Box 4" =>"4",
			"OTHER" =>"0",
			"Book 1" =>"8",
			"Book 2" =>"0",
			"Book 3" =>"0",
			"Book 4" =>"0",
			"Book 5" =>"0",
			"Flask Bottle" =>"2.304",
			"Dipers" =>"4",
			"Mobile Phone" =>"5.6",
			"Prada Scarf Box" =>"7.90125",
			"ECOBABY" =>"0",
			"Pannolino Lavabile" =>"3.8",
			"Inserti Assorbenti" =>"3.8",
			"Veli Cattura Pupù" =>"12",
			"CAMBIO PANNOLINO" =>"0",
			"Kit Cambio Pannolino" =>"12",
			"Balsamo Cambio Ecobaby" =>"2",
			"Spray Cambio Ecobaby" =>"2",
			"Cubetti Terra Gaia" =>"2",
			"Salviette Lavabili Banana" =>"10",
			"Veli Anti Arrossamento" =>"5",
			"Borsa Cambio Bambino Mio" =>"40",
			"Telo Cambio Assorbente" =>"24",
			"Telo Cambio per Mare" =>"24",
			"Mussola Terra Gaia" =>"32",
			"PANNOLINI PER ADULTI" =>"0",
			"Boxer Uomo Incontinenza" =>"2.5",
			"Slip Uomo Incontinenza" =>"2.5",
			"Slip Donna Vita Alta" =>"2.5",
			"Slip Donna Classic" =>"2.5",
			"Pannolino Lavabile Adulti" =>"5"
		];
		update_option('movo_product_tags', json_encode($movo_product_tags));

		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => 'https://phpstack-899427-3122278.cloudwaysapps.com/api/sync_movo_essentials',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => array(
				'Authorization: Bearer '.@get_option('store_access_token')
			),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		
		$products = json_decode($response, true)['products'];

		$ids = [];
		$bags = [];
		$level_from = 0;
		$category = get_term_by( 'slug', 'movo-cat', 'product_cat' );
		if(@$products){
			$existing = get_option('movo_product_ids');
			if(!empty(json_decode($existing))){	
				foreach(json_decode($existing) as $id){
					wp_delete_post($id, true);
				}
			}
			foreach($products as $key => $single){
				$product = new WC_Product_Simple();
				$upload_dir = wp_upload_dir();
				$image_url = 'https://phpstack-899427-3122278.cloudwaysapps.com/'.$single['image'];
				$image_data = file_get_contents( $image_url );

				$filename = basename( $image_url );

				if ( wp_mkdir_p( $upload_dir['path'] ) ) {
					$file = $upload_dir['path'] . '/' . $filename;
				}
				else {
					$file = $upload_dir['basedir'] . '/' . $filename;
				}

				file_put_contents( $file, $image_data );

				$wp_filetype = wp_check_filetype( $filename, null );

				$attachment = array(
					'post_mime_type' => $wp_filetype['type'],
					'post_title' => sanitize_file_name( $filename ),
					'post_content' => '',
					'post_status' => 'inherit'
				);

				$attach_id = wp_insert_attachment( $attachment, $file );
				$product->set_name( $single['name'] );
				$product->set_regular_price( $single['price'] );
				$product->set_category_ids( array($category->term_id) );
				// $product->set_status( 'private' );
				$product->set_image_id( $attach_id );
				$product->save();
				$ids[] = $product->get_id();

				$supported_volume = $single['volume'];
				$bags[] = [
					'level_from' => $level_from,
					'level_to' => $supported_volume,
					'product_id' => $product->get_id()
				];

				$level_from = $supported_volume;
			}
			update_option('movo_bags', json_encode($bags));

			update_option('movo_product_ids', json_encode($ids));
		}

		echo "<script type='text/javascript'>window.location=document.location.href;</script>";	
	}
	?>	
	<div class="movo-card">
		<div class="movo-card-header" style="border-bottom: 0px;">
			<h4>Store Access Token</h4>
			<form action="" method="post">
				<?php if(!empty(get_option('store_access_token')) && is_plugin_active('woocommerce/woocommerce.php')){ ?>
					<button type="submit" name="movo_token_sync" class="movo-token-sync" href="#">
						SYNC
					</button>
				<?php } ?>
			</form>
		</div>
		<form action="" method="post">

			<label style="padding: 5px 11px">Access Tooken</label>
			<div class="movo-card-content" style="padding: 5px 11px; display: flex;">
				<input type="text" name="store_access_token" style="width: 90%;font-size: 16px;padding: 2px 8px;" value="<?= @get_option('store_access_token') ?>">
				<button type="submit" name="movo_token_save" class="movo-token-save">Save</button>
			</div>
		</form>
	</div>
	<form action="" method="post">
		<div class="movo-card" style="margin-top: 20px">
			<div class="movo-card-header">
				<h4>Language</h4>
			</div>
			<div class="movo-card-content" style="padding: 5px 11px;padding-top: 5px !important;">
				<label for="">Choose Movo content language</label>
				<ul class="movo-toggle-ul">
					<?php 
					$movo_language = @get_option('movo_language');
									// echo "<pre>";
									// print_r($movo_language);
					?>
					<li>
						<input type="radio" value="en" <?php if($movo_language == "en") { echo "checked"; } ?> id="f-option1" name="movo_language">
						<label for="f-option1">English <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">I like it in English.</span></label>
						<div class="check"></div>
					</li>
					<li>
						<input type="radio" value="it" <?php if($movo_language == "it") { echo "checked"; } ?> id="s-option1" name="movo_language">
						<label for="s-option1">Italian <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">Mi piace in Italiano.</span></label>
						<div class="check"><div class="inside"></div></div>
					</li>
				</ul>
				<div style="text-align: right;padding-right: 12px;margin-top: 25px">
					<button type="submit" name="submit_bags" class="movo-submit" style="padding: 7px 21px;">Save Changes</button>
				</div>
			</div>
		</div>
	</form>
</div>