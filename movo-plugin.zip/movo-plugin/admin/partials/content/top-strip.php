<div id="Top Strip" class="movo-tabcontent " style="display: block;">
				
				<div class="movo-content">
					<div class="movo-card">
						<?php
						$all_images = json_decode(get_option('movo_images_ids'));
						$movo_language = get_option('movo_language');
						if(is_array($all_images)){
							$black = array_column($all_images, 'TopStripBlack.png')[0];
							$light = array_column($all_images, 'TopStripBlue.png')[0];
						}
						
						$top_strip = json_decode(@get_option('movo_top_strip'));
						?>
						<input type="hidden" class="dark_image_demo" value="<?= wp_get_attachment_image_url(@$black, 'large'); ?>">
						<input type="hidden" class="light_image_demo" value="<?= wp_get_attachment_image_url(@$light, 'large'); ?>">
						<?php
						$movo_top_strip_settings = json_decode(get_option('movo_top_strip'));
						if(empty($top_strip)){
							?>
							<img src="<?= wp_get_attachment_image_url(@$black, 'large'); ?>" class="top_strip_demo" alt="">
							<?php
						}else{
							// echo "<pre>";
							// print_r($movo_top_strip_settings);
							if($movo_top_strip_settings->movo_top_strip_mode == 'dark'){
								?>
								<img src="<?= wp_get_attachment_image_url(@$black, 'large'); ?>" class="top_strip_demo" alt="">

								<?php
							}else{
								?>
								<img src="<?= wp_get_attachment_image_url(@$light, 'large'); ?>" class="top_strip_demo" alt="">
								<?php
							}
						}


						if(isset($_POST['submit_top_strip'])){

							$data = json_encode([
								'enable_top_strip' => $_POST['enable_top_strip'],
								'movo_top_strip_mode' => $_POST['movo_top_strip_mode']
							]);
							if(empty(get_option('movo_top_strip'))){
								add_option('movo_top_strip', $data);
							}else{

								update_option('movo_top_strip', $data);
							}
							echo "<script type='text/javascript'>window.location=document.location.href;</script>";
						}
						?>
						
					</div>
					<form action="" method="post">
						<div class="movo-card" style="padding: 10px;margin-top: 12px">
							<div class="movo-card-header">
								<h4>Top strip</h4>
								<label class="switch">
									<input type="checkbox" <?php if($movo_top_strip_settings->enable_top_strip == '1'){ echo "checked"; } ?> class="movo-toggle" name="enable_top_strip" value="1" />
									<span class="slider round"></span>
								</label>
							</div>
							<div class="movo-card-content">
								<h5>Appearance</h5>
								<ul class="movo-toggle-ul">
									
									<li>
										<input type="radio" class="movo_top_strip_mode movo-stripe" <?php if($movo_top_strip_settings->movo_top_strip_mode == 'light'){ echo "checked"; } ?> value="light" id="s-option"  name="movo_top_strip_mode">
										<label for="s-option">Light Mode <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">For the light mode lovers.</span></label>

										<div class="check"><div class="inside"></div></div>
									</li>
									<li>
										<input type="radio" value="dark" <?php if($movo_top_strip_settings->movo_top_strip_mode == 'dark'){ echo "checked"; } ?> class="movo_top_strip_mode movo-stripe" id="f-option" name="movo_top_strip_mode">
										<label for="f-option">Dark Mode <span style="margin-top: 10px !important;display: block;font-size: 0.875rem;">For the dark mode lovers.</span></label>

										<div class="check"></div>
									</li>
								</ul>
								<div style="text-align: right">
									<button type="submit" name="submit_top_strip" class="movo-submit">Save Changes</button>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>