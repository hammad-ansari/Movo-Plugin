<?php
	/**
	* The public-facing functionality of the plugin.
	*
	* @link       https://dixeam.com
	* @since      1.0.0
	*
	* @package    Movo
	* @subpackage Movo/public
	*/

	/**
	* The public-facing functionality of the plugin.
	*
	* Defines the plugin name, version, and two examples hooks for how to
	* enqueue the public-facing stylesheet and JavaScript.
	*
	* @package    Movo
	* @subpackage Movo/public
	* @author     Dixeam <info@dixeam.com>
		*/
	class Movo_Public {

			/**
			* The ID of this plugin.
			*
			* @since    1.0.0
			* @access   private
			* @var      string    $plugin_name    The ID of this plugin.
			*/
			private $plugin_name;

			/**
			* The version of this plugin.
			*
			* @since    1.0.0
			* @access   private
			* @var      string    $version    The current version of this plugin.
			*/
			private $version;

			/**
			* Initialize the class and set its properties.
			*
			* @since    1.0.0
			* @param      string    $plugin_name       The name of the plugin.
			* @param      string    $version    The version of this plugin.
			*/
			public function __construct( $plugin_name, $version ) {

				$this->plugin_name = $plugin_name;
				$this->version = $version;

			}

			/**
			* Register the stylesheets for the public-facing side of the site.
			*
			* @since    1.0.0
			*/
			public function enqueue_styles() {

				/**
				* This function is provided for demonstration purposes only.
				*
				* An instance of this class should be passed to the run() function
				* defined in Movo_Loader as all of the hooks are defined
				* in that particular class.
				*
				* The Movo_Loader will then create the relationship
				* between the defined hooks and the functions defined in this
				* class.
				*/

				wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/movo-public.css', array(), $this->version, 'all' );
				wp_enqueue_style( $this->plugin_name, 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css', array(), $this->version, 'all' );

			}

			/**
			* Register the JavaScript for the public-facing side of the site.
			*
			* @since    1.0.0
			*/
			public function enqueue_scripts() {

				/**
				* This function is provided for demonstration purposes only.
				*
				* An instance of this class should be passed to the run() function
				* defined in Movo_Loader as all of the hooks are defined
				* in that particular class.
				*
				* The Movo_Loader will then create the relationship
				* between the defined hooks and the functions defined in this
				* class.
				*/

				wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/movo-public.js', array( 'jquery' ), $this->version, false );
			}
			public static function remove_existing_movo_products() {
				

				$movo_product_ids = json_decode(get_option('movo_product_ids'));
				
				foreach($movo_product_ids as $key => $single){
					$product_cart_id = WC()->cart->generate_cart_id( $single );
					$cart_item_key = WC()->cart->find_product_in_cart( $product_cart_id );
					if ( $cart_item_key ){
						WC()->cart->remove_cart_item( $cart_item_key );
					}
				}
				
			}
			public function movo_before_checkout_form(){
				if(@$_SESSION['movo_bag_status_cart']){

					if(@$_SESSION['movo_bag_status_cart'] == '1'){
						$cart_movo_status = 1;
					}else{
						$cart_movo_status = 0;
					}
				}else{
					if(@get_option('movo_checked_on_cart') == 1){
						$cart_movo_status = 1;
					}else{
						$cart_movo_status = 0;
					}
				}

				if($cart_movo_status == 1){
					$this->remove_existing_movo_products();
					$this->adjust_movo_products();
				}elseif($cart_movo_status == 0){
					$this->remove_existing_movo_products();
				}
			}
			private function adjust_bag_volume($remaining){
				
				global $woocommerce;
				$movo_bags =json_decode(get_option('movo_bags', true));
				foreach($movo_bags as $key => $bag){

					if($key == 3){
						$extra_large_bag = $bag->product_id;
						$max_supported_volume = $bag->level_to;
						$woocommerce->cart->add_to_cart( $extra_large_bag );
						$remaining_now = $remaining - $max_supported_volume;
						if($remaining_now > 0){
							return $this->adjust_bag_volume($remaining_now);
						}else{
							return;
						}
					}
				}


			}
			public function movo_order_before_submit(){
// 				if(!session_id()) {
// 					session_start();
// 				}
				if(@$_SESSION['movo_bag_status_cart']){

					if(@$_SESSION['movo_bag_status_cart'] == '1'){
						$cart_movo_status = 1;
					}else{
						$cart_movo_status = 0;
					}
				}else{
					if(@get_option('movo_checked_on_cart') == 1){
						$cart_movo_status = 1;
					}else{
						$cart_movo_status = 0;
					}
				}

				if($cart_movo_status == 1){
					$this->remove_existing_movo_products();
					$this->adjust_movo_products();
				}elseif($cart_movo_status == 0){
					$this->remove_existing_movo_products();
				}

			}
			public function adjust_movo_products() {

				global $woocommerce, $product;
				$total_volume = 0;
				
				foreach ( WC()->cart->get_cart() as $cart_item ){
					
					$product_id = $cart_item['data']->get_id();
					$product_volume = get_post_meta($product_id, 'movo_product_level_field', true);
					
					
					if(!empty($product_volume)){
						$total_volume += @$product_volume * @$cart_item['quantity'];
					}
				}
				$movo_bags =json_decode(get_option('movo_bags'));
				foreach($movo_bags as $key => $bag){
					if( ($bag->level_from <= $total_volume) && ($total_volume <= $bag->level_to) ){

						$woocommerce->cart->add_to_cart( $bag->product_id );
						return;
					}

					
					if($key == 3){

						$extra_large_bag = $bag->product_id;
						$max_supported_volume = $bag->level_to;
						$woocommerce->cart->add_to_cart( $extra_large_bag );
						$remaining = $total_volume - $max_supported_volume;
						
						return $this->adjust_bag_volume($remaining);
					}
				}
				

			}
			public function movo_checkout_onchange(){
// 				@session_start();
				if($_POST['movo_bag_status'] == 1){
					$this->remove_existing_movo_products();
					$this->adjust_movo_products();
					$_SESSION['movo_bag_status_cart'] = 1;
				}elseif($_POST['movo_bag_status'] == 0){
					$this->remove_existing_movo_products();
					$_SESSION['movo_bag_status_cart'] = 0;

				}
			}

			public function movo_cart_onchange(){
// 				@session_start();
				
				if($_POST['movo_bag_status_cart'] == 1){
					
					$_SESSION['movo_bag_status_cart'] = 1;
					$this->remove_existing_movo_products();
					$this->adjust_movo_products();
				}else{
					$_SESSION['movo_bag_status_cart'] = 0;
					$this->remove_existing_movo_products();
				}
				print_r($_SESSION);
				exit();
			}


			public function add_top_strip(){

				$top_strip_settings = json_decode(get_option('movo_top_strip'));
				$movo_language = @get_option('movo_language');
				if(@$top_strip_settings->enable_top_strip == 1){
					if ($top_strip_settings->movo_top_strip_mode == "dark") {
						$mode = "movo_dark";
					} else {
						$mode = "movo_light";
					}
					if ($movo_language == "en") {
						$content = "Your order cares for the environment. 
						<a href='#' class='ml-1' onclick='document.getElementById(".'"'."id03".'"'.").style.display=".'"'."block".'"'."'>Learn more ></a>";
						$pop_li = "Select Movo at check out and place your order";
						$pop_li1 = "Get your order delivered in a reusable packaging";
						$pop_li2 = "Fold the package once emptied and leave it into your nearest postal office.";
						$pop_li3 = "No need for queuing!";
						$pop_li4 = "Continue shopping consciously";
						$power = "Powered By";
					} 
					else {
						$content = "E-commerce sostenibile grazie a Movo. <a href='#' class='ml-1' onclick='document.getElementById(".'"'."id03".'"'.").style.display=".'"'."block".'"'."'>Scopri di più ></a>";
						$pop_li = "Scegli l’opzione Movo al ckeck out e procedi con l’acquisto";
						$pop_li1 = "Ricevi il tuo ordine consegnato in un imballaggio riutilizzabile";
						$pop_li2 = "Ripiega il pacco e imbucalo nella casetta postale più vicina. ";
						$pop_li3 = "Senza fare la fila!";
						$pop_li4 = "Continua gli acquisti consapevoli";
						$power = "Offerto da";
					}
					echo '
					
					<div class="movo_alert '.$mode.'"><input type="checkbox" id="alert2"/><label class="close"><i class="movo-icon-remove" onclick="document.getElementById('."'".'movo_inner'."'".').style.display='."'".'none'."'".'">x</i></label> 
					<p class="movo_inner" id="movo_inner"><img class="" style="margin-right:8px;" src="'.get_site_url().'/wp-content/plugins/movo-plugin/includes/images/image 17.png">'.$content.'</p>
					
					<div id="id05" class="movo-modal">
					<div class="movo-modal-content ">
					<span onclick='."'".'document.getElementById("id05").style.display="none"'."'".' class="movo-close">&times;</span>
					<div class="movo-pop">
					<img class="movo-popup-img" src="'. plugin_dir_url(__DIR__).'includes/images/Movo Reusable Packaging 3.gif;">
					</div>
					<div class="list">
					<ul>
					<li>
					<span>
					<img class="" src="'. plugin_dir_url(__DIR__).'includes/images/image 16.png;">
					</span>
					<span class="movo-pop-li">'. $pop_li.'</span>
					</li>
					<li>
					<span>
					<img class="" src="'.plugin_dir_url(__DIR__).'includes/images/image 16.png;">
					</span>
					<span class="movo-pop-li">'. $pop_li1 .'</span>
					</li>
					<li><span>
					<img class=" movo-pop-img" style="
					width: 26px !important;
					" src="'. plugin_dir_url(__DIR__).'includes/images/image 16.png;">
					</span>
					<span class="movo-pop-li">'. $pop_li2 .'<span class="movo-pop-li-3">'. $pop_li3 .'</span> </span></li>
					</ul>
					</div>
					<a class="movo-btn-pop" style="color:white !important;text-align: center;">
					'. $pop_li4.'
					</a>
					<div class="movo-powered-pop">
					<div class="movo-powered-pop1">
					<span>
					'.$power.'	
					</span>
					<span style="    margin-bottom: 25px;">
					<img class="movo-img1" src="'. plugin_dir_url(__DIR__).'includes/images/image 20.png;">
					</span>
					</div>
					</div>

					</div>
					</div>

					';
					
				}
			}

			public function add_footer_strip(){

				$footer_strip_settings = json_decode(get_option('movo_footer_strip'));
				$movo_language = @get_option('movo_language');
				if(@$footer_strip_settings->enable_footer_strip == 1){
					if ($footer_strip_settings->movo_footer_strip_mode == "dark") {
						$mode = "movo_dark";
						$logo_src = "image 21.png";
						$logo_color = "text-white";
						$icon_color = "text-white";
						$line_color = "bg-white";
					} else if ($footer_strip_settings->movo_footer_strip_mode == "light") {
						$mode = "movo_light";
						$logo_src = "image 20.png";
						$logo_color = "text-blue";
						$icon_color = "text-blue";
						$line_color = "bg-grey";
					} else {
						$mode = "movo_grey";
						$logo_src = "image 21.png";
						$logo_color = "text-white";
						$icon_color = "text-white";
						$line_color = "bg-white";
					}
					if ($movo_language == "en") {
						$content = "Choose sustainable packaging that do not belong in the trash.";
						$reusable_text = "Get your order delivered in a reusable packaging";
						$pop_li1 = "Scegli l’opzione Movo al ckeck out e procedi con l’acquisto";
						$pop_li11 = "Ricevi il tuo ordine consegnato in un imballaggio riutilizzabile";
						$pop_li21 = "Ripiega il pacco e imbucalo nella casetta postale più vicina. ";
						$pop_li31 = "Senza fare la fila!";
						$pop_li41 = "Continua gli acquisti consapevoli";
						$power = "Powered By";

					} else {
						$content = "Scegli il packaging circolare più sostenibile al mondo.";
						$reusable_text = "Get your order delivered in a reusable packaging";
						$pop_li1 = "Scegli l’opzione Movo al ckeck out e procedi con l’acquisto";
						$pop_li11 = "Ricevi il tuo ordine consegnato in un imballaggio riutilizzabile";
						$pop_li21 = "Ripiega il pacco e imbucalo nella casetta postale più vicina. ";
						$pop_li31 = "Senza fare la fila!";
						$pop_li41 = "Continua gli acquisti consapevoli";
						$power = "Offerto da";

					}
					?>

					
					<div class="movo_footer <?= $mode; ?>">
						<div class="movo_footer_inner">
							<hr class="<?= $line_color; ?>">
							<div class="movo_footer_content">
								<p>
									

									<span class="movo-content">
										<img class="movo-checkout-img" src="<?= plugin_dir_url(__DIR__).'includes/images/Schermata 2022-12-03 alle 12.02 1.png'; ?>">
										<span class="movo-circular" style="margin-top: 6px !important;right: 13px !important;">Go circular</span>
									</span>

									<span class="<?= $logo_color; ?>" style="font-size: 15px;font-weight: 700;display: inline-block;
"><?= $content; ?></span>
								</p>
								<div class="text-muted">
									<?= $power; ?>
									<div style="margin-top: -3px;">
										<b>
											<img style="margin-left: 8px !important; margin-right: 8px !important; " src="<?= plugin_dir_url(__DIR__).'includes/images/'.$logo_src; ?>">
										</b>
										<div id="id03" class="movo-modal">
											<div class="movo-modal-content ">
												<span onclick="document.getElementById('id03').style.display='none'" class="movo-close">&times;</span>


												<div class="movo-pop">
													<img class="movo-popup-img" src="<?= plugin_dir_url(__DIR__).'includes/images/Movo Reusable Packaging 3.gif'; ?>">
												</div>
												<div class="list">
													<ul>
														<li>
															<div>
																<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
															</div>
															<div class="movo-pop-li"><?php echo $pop_li1; ?></div>
														</li>
														<li>
															<div>
																<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
															</div>
															<div class="movo-pop-li"><?php echo $pop_li11; ?></div>
														</li>
														<li>
															<div>
																<img class="" style="
																width: 26px !important;
																" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
															</div>
															<div class="movo-pop-li"><?php echo $pop_li21; ?> <span class="movo-pop-li-3"><?php echo $pop_li31; ?></span> </div>
														</li>
														
													</ul>

												</div>
												<div style="display: flex;margin-top: 20px;justify-content: center !important;">
													<a class="movo-btn-pop" style="color:white !important;text-align: center;">
														<?php echo $pop_li41; ?>
													</a>
												</div>
												<div class="movo-powered-pop">
													<div class="movo-powered-pop1">
														<span>
															<?= $power; ?>	
														</span>
														<span style="    margin-bottom: 25px;">
															<img class="movo-img1" src="<?= plugin_dir_url(__DIR__).'includes/images/image 20.png'; ?>">
														</span>
													</div>
												</div>

											</div>
										</div>
										<svg xmlns="http://www.w3.org/2000/svg" onclick="document.getElementById('id03').style.display='block'"  width="16" height="16" fill="currentColor" class="popup-svg bi bi-info-circle  popupfooter <?= $icon_color; ?>" viewBox="0 0 16 16" style="position: relative; top: 0px;">
											<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
											<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
										</svg>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
			}

			?>

			<script>
				jQuery(document).on('change', '.movo-bag-check', function(){
					$ = jQuery;
					$.ajax({
						data: {
							action: 'movo_checkout_onchange',
							'movo_bag_status': $('.movo-bag-check:checked').val(),
						},
						type: 'post',
						url: '<?= admin_url('admin-ajax.php'); ?>',
						success: function(response_from_movo_checkout_onchange) {
							jQuery(document.body).trigger('update_checkout');

						}
					});
				})

				jQuery(document).on('change', '.movo_bag_status_cart', function(){
					$ = jQuery;
					var checked_movo = $('.movo_bag_status_cart:checked').val();
					
					$.ajax({
						data: {
							action: 'movo_cart_onchange',
							'movo_bag_status_cart': checked_movo,
						},
						type: 'post',
						url: '<?= admin_url('admin-ajax.php'); ?>',
						success: function(response_from_movo_cart_onchange) {
							jQuery( "[name='update_cart']" ).removeAttr( 'disabled' );
							jQuery( "[name='update_cart']" ).trigger( 'click' );


						}
					});
				})

			</script>
			<?php
		}
		public function movo_order_completed($order_id) {
			$order = new WC_Order( $order_id );
			$movo_order_array = [];


			$movo_order_array['platform'] = "Wordpress";
			$movo_order_array['order_id'] = $order_id;
			$movo_order_array['order_name'] = '"#'.$order_id.'"';
			$movo_order_array['order_total_price'] = $order->get_total();
			$movo_order_array['order_currency'] = $order->get_currency();
			$movo_order_array['customer'] = [
				'id' => $order->get_customer_id(),
				'email' => $order->get_billing_email(),
				'name' => $order->get_billing_first_name()
			];
			$movo_product_ids = json_decode(get_option('movo_product_ids'));
			$movo_order_array['movo_packs'] = [];
			foreach ( $order->get_items() as $item_id => $item ) {

				if(in_array($item->get_product_id(), $movo_product_ids)){
					$_product = wc_get_product($item->get_product_id());
					$movo_order_array['movo_packs'][] = [
						'name' => $_product->get_name(),
						'price' => $_product->get_regular_price(),
						'quantity' => $item->get_quantity(),
						'variant_id' => $item->get_product_id(),
						'product_id' => $item->get_product_id()
					];
				}
			}
			$movo_order_array['full_order'] = $order->get_data();
			$movo_order_json = json_encode($movo_order_array);
				// CURL 
			if(!empty(get_option('store_access_token'))){
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => 'https://phpstack-899427-3122278.cloudwaysapps.com/api/order_process',
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS =>$movo_order_json,
					CURLOPT_HTTPHEADER => array(
						'Authorization: Bearer '.get_option('store_access_token'),
						'Content-Type: application/json'
					),
				));

				$response = curl_exec($curl);
				curl_close($curl);
				unset($_SESSION['movo_bag_status_cart']);
			}





		}
		public function before_shipping_cart_page(){
			$movo_language = @get_option('movo_language');
// 			@session_start();
			if(@$_SESSION['movo_bag_status_cart']){

				if(@$_SESSION['movo_bag_status_cart'] == '1'){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
			}else{
				if(@get_option('movo_checked_on_cart') == 1){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
			}

			if ($movo_language == "en") {
				$content_checkout = "Sustainable, reusable packaging";
				$popup_checkout = "Carboard box";
				$chckout_non = "Non sustainable 😢";
				$checkout_span1= "Free";
				$checkout_cart = "With Movo’s circular packaging you get your order and instead of throwing packaging to the trash, you mail it back to give it a new life.";
				$checkout_span= "See how it works";
				$pop_li1 = "Select Movo at check out and place your order";
				$pop_li11 = "Get your order delivered in a reusable packaging";
				$pop_li21 = "Fold the package once emptied and leave it into your nearest postal office.";
				$pop_li31 = "No need for queuing!";
				$pop_li41 = "Continue shopping consciously";
				$power = "Powered By";
			} 
			else {
				$content_checkout = "Packaging sostenibile";
				$popup_checkout = "Scatola in cartone";
				$chckout_non = "Non sostenibile 😢";
				$checkout_span1= "Gratis";
				$checkout_cart = "Con il packaging circolare di Movo ricevi il tuo ordine e invece di gettare l’imballaggio nel cestino, lo spedisci per dargli una nuova vita.";
				$checkout_span= "Scopri come funziona";
				$pop_li1 = "Scegli l’opzione Movo al ckeck out e procedi con l’acquisto";
				$pop_li11 = "Ricevi il tuo ordine consegnato in un imballaggio riutilizzabile";
				$pop_li21 = "Ripiega il pacco e imbucalo nella casetta postale più vicina. ";
				$pop_li31 = "Senza fare la fila!";
				$pop_li41 = "Continua gli acquisti consapevoli";
				$power = "Offerto da";
			}
			?>

			<div class="movo-checkout-box">
				<div class="movo-box">
					<div class="movo-tooltip-content-main-content">
						<div>
							<input type="radio" value="1" class="movo-radio-btn movo-bag-check" name="movo-bag-radio" <?php if(@$cart_movo_status == 1){ echo "checked"; } ?> >
						</div>
						<div>
							<span><?php echo $content_checkout; ?></span>
						</div>
						<div id="id02" class="movo-modal">
							<div class="movo-modal-content ">
								<span onclick="document.getElementById('id02').style.display='none'" class="movo-close">&times;</span>
								<div class="movo-pop">
									<img class="movo-popup-img" src="<?= plugin_dir_url(__DIR__).'includes/images/Movo Reusable Packaging 3.gif'; ?>">
								</div>
								<div class="list">
									<ul>
										<li>
											<span>
												<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
											</span>
											<span class="movo-pop-li"><?php echo $pop_li1; ?></span>
										</li>
										<li>
											<span>
												<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
											</span>
											<span class="movo-pop-li"><?php echo $pop_li11; ?></span>
										</li>
										<li>
											<span>
												<img class=" movo-pop-img" style="
												width: 26px !important;
												" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
											</span>
											<span class="movo-pop-li"><?php echo $pop_li21; ?> <span class="movo-pop-li-3"><?php echo $pop_li31; ?></span> </span>
										</li>
										
									</ul>
								</div>
								<div style="display: flex; margin-top: 20px; justify-content: center !important;">
									<a class="movo-btn-pop" style="color:white !important;text-align: center;">
										<?php echo $pop_li41; ?>
									</a>
								</div>
								<div class="movo-powered-pop">
									<div class="movo-powered-pop1">
										<span>
											<?= $power; ?>											
										</span>
										<span style="    margin-bottom: 25px;">
											<img class="movo-img1" src="<?= plugin_dir_url(__DIR__).'includes/images/image 20.png'; ?>">
										</span>
									</div>
								</div>

							</div>
						</div>
						<div class="movo-tooltip popup">
							<span class="popuptext movo-tooltiptext" style="margin:-6px -291px !important; width: 542px !important; border:1px solid #bbb !important;" >
								<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>"> 
								<?php echo $checkout_cart; ?>
								<span onclick="document.getElementById('id02').style.display='block'" style="color:#02C39A; font-weight: 700;">
									<?php echo $checkout_span; ?>
									<svg height="" viewBox="0 0 512 512" class="movo-svg-chceckd" width="25" xmlns="http://www.w3.org/2000/svg" style="position: absolute !important; top: 80px !important;"><title/><polyline points="268 112 412 256 268 400" style=" fill:none;stroke:#02C39A;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px"/><line style="fill:none;stroke:#02C39A;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px" x1="392" x2="100" y1="256" y2="256"/></svg>
								</span>
							</span>
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle movo-svg movo-tooltip" style="top: 0px; left: 4px !important; position: relative !important;" viewBox="0 0 16 16">
								<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
								<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>
							</svg>
						</div>
						
						<span class="movo-content">
							<img class="movo-checkout-img" src="<?= plugin_dir_url(__DIR__).'includes/images/Schermata 2022-12-03 alle 12.02 1.png'; ?>">
							<span class="movo-circular">Go circular</span>
						</span>
					</div>
					<div class="movo-checkout-box-price">
						<span class="movo-price">€ 3,50 </span>
					</div>
				</div>
				<div class="movo-powered1">
					<span>
						<?= $power; ?>
					</span>
					<img class="movo-img1" style="margin-top: 7px !important" src="<?= plugin_dir_url(__DIR__).'includes/images/image 20.png'; ?>">
				</div>
			</div>
			<div class="movo-checkout-box1">
				<div class="movo-box">
					<div class="movo-tooltip-content-main-content">
						<div>
							<input type="radio" class="movo-radio-btn movo-bag-check" value="0" name="movo-bag-radio" <?php if(@$cart_movo_status == 0){ echo "checked"; } ?>>
							
						</div>
						<span><?php echo $popup_checkout?></span>
					</div>
					<div class="movo-checkout-box-price">
						<span class="movo-price1"><?php echo $checkout_span1; ?>  </span>
					</div>
				</div>
				<div class="movo-powered1">
					<?php echo $chckout_non; ?>
				</div>
			</div>

		</script>
		<?php
	}
	public function movo_on_cart_update($cart_updated){
		$movo_status_cart = $_SESSION['movo_bag_status_cart'];
		
		if(@$_SESSION['movo_bag_status_cart']){
			if($movo_status_cart == 1){
				$this->remove_existing_movo_products();
				$this->adjust_movo_products();
			}else{
				$this->remove_existing_movo_products();
			}
		}
	}
	public function movo_cart_calculation(){
		if(@get_option('movo_checked_on_cart') == 1){
			
			$cart_movo_status = 0;
			if(array_key_exists( 'movo_bag_status_cart',@$_SESSION)){
				
				if(@$_SESSION['movo_bag_status_cart'] == '1'){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
				
			}else{
				if(@get_option('movo_checked_on_cart') == 1){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
			}
			
			if($cart_movo_status == 1){
				$this->remove_existing_movo_products();
				$this->adjust_movo_products();
			}elseif($cart_movo_status == 0){
				$this->remove_existing_movo_products();
			}
		}
		
	}

	public function cart_page_movo_section(){
		
		
		if(@get_option('movo_enable_on_cart') == 1){
			$movo_language = @get_option('movo_language');

			if(@$_SESSION['movo_bag_status_cart']){
				if(@$_SESSION['movo_bag_status_cart'] == 1){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
				
				if(@get_option('movo_checked_on_cart') == 1){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
				
			}else{
				
				if(@get_option('movo_checked_on_cart') == 1){
					$cart_movo_status = 1;
				}else{
					$cart_movo_status = 0;
				}
			}

			if ($movo_language == "en") {
				$content_cart = "Avoid trash, get circular packaging for 3,50€ ";
				$popup_cart = "With Movo’s circular packaging you get your order and instead of throwing packaging to the trash, you mail it back to give it a new life.";
				$movo_span= "See how it works";

				$pop_li1 = "Select Movo at check out and place your order";
				$pop_li11 = "Get your order delivered in a reusable packaging";
				$pop_li21 = "Fold the package once emptied and leave it into your nearest postal office.";
				$pop_li31 = "No need for queuing!";
				$pop_li41 = "Continue shopping consciously";
				$power = "Powered By";
			} 
			else {
				$content_cart = "Evita gli sprecchi, richiedi il packaging circolare a 3,50 €";
				$popup_cart = "Con il packaging circolare di Movo ricevi il tuo ordine e invece di gettare l’imballaggio nel cestino, lo spedisci per dargli una nuova vita.";
				$movo_span= "Scopri come funziona";
				$pop_li1 = "Scegli l’opzione Movo al ckeck out e procedi con l’acquisto";
				$pop_li11 = "Ricevi il tuo ordine consegnato in un imballaggio riutilizzabile";
				$pop_li21 = "Ripiega il pacco e imbucalo nella casetta postale più vicina. ";
				$pop_li31 = "Senza fare la fila!";
				$pop_li41 = "Continua gli acquisti consapevoli";
				$power = "Offerto da";
			}

			?>
			<form action="" method="post">
				<div class="cart_page_movo_section">
					<div class="cart_page_movo1">
						<p> <?php  echo $content_cart; ?> </p>
					</div>
					<div class="cart_page_movo2">
						<div>	
							<span class="span"><?= $power; ?></span>
							<img class='movo-img' src="<?= plugin_dir_url(__DIR__).'includes/images/image 20.png'; ?>">
							<div id="id01" class="movo-modal">
								<div class="movo-modal-content ">
									<span onclick="document.getElementById('id01').style.display='none';" class="movo-close">&times;</span>


									<div class="movo-pop">
										<img class="movo-popup-img" src="<?= plugin_dir_url(__DIR__).'includes/images/Movo Reusable Packaging 3.gif'; ?>">
									</div>
									<div class="list">
										<ul>
											<li>
												<span>
													<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
												</span>
												<span class="movo-pop-li"><?php echo $pop_li1; ?></span>
											</li>
											<li>
												<span>
													<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
												</span>
												<span class="movo-pop-li"><?php echo $pop_li11; ?></span>
											</li>
											<li>
												<span>
													<img class=" movo-pop-img" style="
													width: 26px !important;
													" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>">
												</span>
												<span class="movo-pop-li"><?php echo $pop_li21; ?> <span class="movo-pop-li-3"><?php echo $pop_li31; ?></span> </span>
											</li>
											
										</ul>
									</div>
									<div style="display: flex; margin-top: 20px; justify-content: center !important;">
										<a class="movo-btn-pop" style="color:white !important;text-align: center;">
											<?php echo $pop_li41; ?>
										</a>
									</div>
									<div class="movo-powered-pop">
										<div class="movo-powered-pop1">
											<span>
												<?= $power; ?>	
											</span>
											<span style="    margin-bottom: 25px;">
												<img class="movo-img1" src="<?= plugin_dir_url(__DIR__).'includes/images/image 20.png'; ?>">
											</span>
										</div>
									</div>

								</div>
							</div>
							<div class="movo-tooltip popup">
								<span class="popuptext movo-tooltiptext" style="margin:-6px -291px !important; width: 542px !important; border:1px solid #bbb !important;" >
									<img class="" src="<?= plugin_dir_url(__DIR__).'includes/images/image 16.png'; ?>"> 
									<?php echo $popup_cart; ?>
									<span onclick="document.getElementById('id01').style.display='block'" style="color:#02C39A; font-weight: 700;">
										<?php echo $movo_span; ?>
										<svg height="" viewBox="0 0 512 512" class="movo-svg-chceckd" width="25" xmlns="http://www.w3.org/2000/svg" style="position: absolute !important; top: 69px !important;"><title/><polyline points="268 112 412 256 268 400" style=" fill:none;stroke:#02C39A;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px"/><line style="fill:none;stroke:#02C39A;stroke-linecap:round;stroke-linejoin:round;stroke-width:48px" x1="392" x2="100" y1="256" y2="256"/></svg>
									</span>
								</span>
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#05668D" class="bi bi-info-circle movo-svg movo-tooltip" style="top: 0px; left: 4px !important; position: relative !important;" viewBox="0 0 16 16">
									<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
									<path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>
								</svg>
							</div>
							
						</div>
						<div class="cart_page_movo">
							<label class="switch">
								<input type="checkbox" name="movo_bag_status_cart" <?php if($cart_movo_status == 1){ echo "checked"; } ?> class="movo_bag_status_cart" value="1">
								<span class="slider round"></span>
							</label>
						</div>
					</div>
				</div>
			</form>
			<?php

		}
	}


}